﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Linq.Expressions;
using NCalc;
using Symbolism;


namespace C60_Spectyr
{

    class DotProductCalculator
    {
        public struct Point3D
        {
            public double X, Y, Z;
            public Point3D(double x, double y, double z)
            {
                X = x;
                Y = y;
                Z = z;
            }

            public Point3D Negate()
            {
                return new Point3D(-X, -Y, -Z);
            }
            public Point3D Multiply(double factor)
            {
                return new Point3D(X * factor, Y * factor, Z * factor);
            }

            public override string ToString()
            {
                return $"({X}, {Y}, {Z})";
            }
        }

        static double DotProduct(Point3D p1, Point3D p2)
        {
            double dotProduct = p1.X * p2.X + p1.Y * p2.Y + p1.Z * p2.Z;
            return Math.Round(dotProduct, 2); // Round to 6 decimal places
        }
        static double DistanceFromOrigin(Point3D p)
        {
            return Math.Round(Math.Sqrt(p.X * p.X + p.Y * p.Y + p.Z * p.Z)); // Distance rounded to 6 decimal places
        }

        static void Main()
        {
            double r = 1.0; // Define the number r

            double factor = 2 * (r + 1) / Math.Sqrt(4 + r * r * (1 + Math.Sqrt(5)) * (1 + Math.Sqrt(5)));
            // Manually initialize the coordinates for all 72 points
            Point3D[] points = new Point3D[72];
            string[] pointNames = new string[72];

            // Initialize a_i points
            points[0] = new Point3D(1, 0, 0); pointNames[0] = "a_1";
            points[1] = new Point3D(1 / Math.Sqrt(5), 2 / Math.Sqrt(5), 0)
; pointNames[1] = "a_2";
            points[2] = new Point3D(1 / Math.Sqrt(5), (5 - Math.Sqrt(5)) / 10, Math.Sqrt((5 + Math.Sqrt(5)) / 10))
; pointNames[2] = "a_3";
            points[3] = new Point3D(1 / Math.Sqrt(5), (-5 - Math.Sqrt(5)) / 10, Math.Sqrt((5 - Math.Sqrt(5)) / 10))
; pointNames[3] = "a_4";
            points[4] = new Point3D(1 / Math.Sqrt(5), (-5 - Math.Sqrt(5)) / 10, -Math.Sqrt((5 - Math.Sqrt(5)) / 10))
; pointNames[4] = "a_5";
            points[5] = new Point3D(1 / Math.Sqrt(5), (5 - Math.Sqrt(5)) / 10, -Math.Sqrt((5 + Math.Sqrt(5)) / 10))
; pointNames[5] = "a_6";

            // Initialize a_7 to a_12 with ((-1)*(0), (-1)*(0), (-1)*(0))
            points[6] = points[0].Negate(); pointNames[6] = "a_7";
            points[7] = points[1].Negate(); pointNames[7] = "a_8";
            points[8] = points[2].Negate(); pointNames[8] = "a_9";
            points[9] = points[3].Negate(); pointNames[9] = "a_10";
            points[10] = points[4].Negate(); pointNames[10] = "a_11";
            points[11] = points[5].Negate(); pointNames[11] = "a_12";

            // Initialize N_i,j points
            points[12] = new Point3D(1 / (r + 1), (1 + Math.Sqrt(5)) * r / (2 * (r + 1)), 0)
; pointNames[12] = "N_1,1";
            points[13] = new Point3D(1 / (r + 1), r / (2 * (r + 1)), -Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1)))
; pointNames[13] = "N_1,2";
            points[14] = new Point3D(1 / (r + 1), (-(3 + Math.Sqrt(5)) * r) / (4 * (r + 1)), -Math.Sqrt(5 + Math.Sqrt(5)) * r / ((r + 1) * 2 * Math.Sqrt(2)))
; pointNames[14] = "N_1,3";
            points[15] = new Point3D(1 / (r + 1), -(3 + Math.Sqrt(5)) * r / (4 * (r + 1)), Math.Sqrt(5 + Math.Sqrt(5)) * r / ((r + 1) * 2*Math.Sqrt(2)))
; pointNames[15] = "N_1,4";
            points[16] = new Point3D(1 / (r + 1), r / (2 * (r + 1)), Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1)))
; pointNames[16] = "N_1,5";

            points[17] = new Point3D(((5 + Math.Sqrt(5)) * r + Math.Sqrt(5)) / (5 * (r + 1)), ((-5 - Math.Sqrt(5)) * r + 4 * Math.Sqrt(5)) / (10 * (r + 1)), 0); pointNames[17] = "N_2,1";
            points[18] = new Point3D(Math.Sqrt(5) / 5, (Math.Sqrt(5) * (4 - r)) / (10 * (r + 1)), Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1))); pointNames[18] = "N_2,2";
            points[19] = new Point3D(-((3 + Math.Sqrt(5)) * r - 2) / (2 * Math.Sqrt(5) * (r + 1)), ((3 + Math.Sqrt(5)) * r + 8) / (4 * Math.Sqrt(5) * (r + 1)), Math.Sqrt(5 + Math.Sqrt(5)) * r / (2 * Math.Sqrt(2) * (r + 1))); pointNames[19] = "N_2,3";
            points[20] = new Point3D(-((3 + Math.Sqrt(5)) * r - 2) / (2 * Math.Sqrt(5) * (r + 1)), ((3 + Math.Sqrt(5)) * r + 8) / (4 * Math.Sqrt(5) * (r + 1)), -Math.Sqrt(5 + Math.Sqrt(5)) * r / (2 * Math.Sqrt(2) * (r + 1))); pointNames[20] = "N_2,4";
            points[21] = new Point3D(Math.Sqrt(5) / 5, (Math.Sqrt(5) * (4 - r)) / (10 * (r + 1)), -Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1))); pointNames[21] = "N_2,5";

            points[22] = new Point3D(((5 + Math.Sqrt(5)) * r + Math.Sqrt(5)) / (5 * (r + 1)), ((-5 - Math.Sqrt(5)) * r + 4 * Math.Sqrt(5)) / (10 * (r + 1)) * (Math.Sqrt(5) - 1) / 4, ((-5 - Math.Sqrt(5)) * r + 4 * Math.Sqrt(5)) / (10 * (r + 1)) * Math.Sqrt((5 + Math.Sqrt(5)) / 8)); pointNames[22] = "N_3,1";
            points[23] = new Point3D(Math.Sqrt(5) / 5, (5 + Math.Sqrt(5)) / (4 * (r + 1)) + (-15 - 7 * Math.Sqrt(5)) / 20, (Math.Sqrt(50 - 10 * Math.Sqrt(5)) * r + 2 * Math.Sqrt(10 * (5 + Math.Sqrt(5)))) / (20 * (r + 1))); pointNames[23] = "N_3,2";
            points[24] = new Point3D((2 - (3 + Math.Sqrt(5)) * r) / (2 * Math.Sqrt(5) * (1 + r)), -((5 + Math.Sqrt(5)) * r) / (8 * (1 + r)) + ((-1 + Math.Sqrt(5)) * (8 + (3 + Math.Sqrt(5)) * r)) / (16 * Math.Sqrt(5) * (1 + r)), Math.Sqrt((5 + Math.Sqrt(5)) / 10)); pointNames[24] = "N_3,3";
            points[25] = new Point3D(-((3 + Math.Sqrt(5)) * r - 2) / (2 * Math.Sqrt(5) * (r + 1)), (3 * Math.Sqrt(5) * r + 15 * r - 2 * Math.Sqrt(5) + 10) / (20 * (r + 1)), +(Math.Sqrt(2 * (5 + Math.Sqrt(5))) * ((5 - Math.Sqrt(5)) * r + 4 * Math.Sqrt(5))) / (40 * (r + 1))); pointNames[25] = "N_3,4";
            points[26] = new Point3D(Math.Sqrt(5) / 5, ((Math.Sqrt(5) - 1) * (4 - r)) / (8 * Math.Sqrt(5) * (r + 1)) + Math.Sqrt((5 + Math.Sqrt(5)) * (5 + 2 * Math.Sqrt(5)) / 2) * r / (4 * (r + 1)), -(Math.Sqrt(5 * (5 + 2 * Math.Sqrt(5))) * r - Math.Sqrt(10 * (5 + Math.Sqrt(5)))) / (10 * (r + 1))); pointNames[26] = "N_3,5";

            points[27] = new Point3D(((5 + Math.Sqrt(5)) * r + Math.Sqrt(5)) / (5 * (r + 1)), ((5 + 3 * Math.Sqrt(5)) * r - 2 * (5 + Math.Sqrt(5))) / (20 * (r + 1)), (Math.Sqrt((5 - Math.Sqrt(5)) / 2) * ((-5 - Math.Sqrt(5)) * r + 4 * Math.Sqrt(5))) / (20 * (r + 1))); pointNames[27] = "N_4,1";
            points[28] = new Point3D(Math.Sqrt(5) / 5, (Math.Sqrt(5) * (4 - r)) / (10 * (r + 1)) * (-Math.Sqrt(5) - 1) / 4 + Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8), (Math.Sqrt(5) * (4 - r)) / (10 * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8) - Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1)) * (-Math.Sqrt(5) - 1) / 4); pointNames[28] = "N_4,2";
            points[29] = new Point3D(-((3 + Math.Sqrt(5)) * r - 2) / (2 * Math.Sqrt(5) * (r + 1)), ((3 + Math.Sqrt(5)) * r + 8) / (4 * Math.Sqrt(5) * (r + 1)) * (-Math.Sqrt(5) - 1) / 4 - Math.Sqrt(5 + Math.Sqrt(5)) * r / (2 * Math.Sqrt(2) * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8), ((3 + Math.Sqrt(5)) * r + 8) / (4 * Math.Sqrt(5) * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8) + Math.Sqrt(5 + Math.Sqrt(5)) * r / (2 * Math.Sqrt(2) * (r + 1)) * (-Math.Sqrt(5) - 1) / 4); pointNames[29] = "N_4,3";
            points[30] = new Point3D(-((3 + Math.Sqrt(5)) * r - 2) / (2 * Math.Sqrt(5) * (r + 1)), ((3 + Math.Sqrt(5)) * r + 8) / (4 * Math.Sqrt(5) * (r + 1)) * (-Math.Sqrt(5) - 1) / 4 + Math.Sqrt(5 + Math.Sqrt(5)) * r / (2 * Math.Sqrt(2) * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8), ((3 + Math.Sqrt(5)) * r + 8) / (4 * Math.Sqrt(5) * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8) - Math.Sqrt(5 + Math.Sqrt(5)) * r / (2 * Math.Sqrt(2) * (r + 1)) * (-Math.Sqrt(5) - 1) / 4); pointNames[30] = "N_4,4";
            points[31] = new Point3D(Math.Sqrt(5) / 5, (Math.Sqrt(5) * (4 - r)) / (10 * (r + 1)) * (-Math.Sqrt(5) - 1) / 4 - Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8), (Math.Sqrt(5) * (4 - r)) / (10 * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8) + Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1)) * (-Math.Sqrt(5) - 1) / 4); pointNames[31] = "N_4,5";

            points[32] = new Point3D(((5 + Math.Sqrt(5)) * r + Math.Sqrt(5)) / (5 * (r + 1)), ((5 + 3 * Math.Sqrt(5)) * r - 2 * (5 + Math.Sqrt(5))) / (20 * (r + 1)), (Math.Sqrt((5 - Math.Sqrt(5)) / 2) * (-(-5 - Math.Sqrt(5)) * r - 4 * Math.Sqrt(5))) / (20 * (r + 1))); pointNames[32] = "N_5,1";
            points[33] = new Point3D(Math.Sqrt(5) / 5, ((5 + Math.Sqrt(5)) * (3 * r - 2)) / (20 * (r + 1)), (Math.Sqrt(5) * (4 - r)) / (10 * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8) - Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1)) * (-Math.Sqrt(5) - 1) / 4); pointNames[33] = "N_5,2";
            points[34] = new Point3D(-((3 + Math.Sqrt(5)) * r - 2) / (2 * Math.Sqrt(5) * (r + 1)), (3 * Math.Sqrt(5) * r - 5 * r - 2 * Math.Sqrt(5) - 10) / (20 * (r + 1)), (Math.Sqrt(5) * (4 - r)) / (10 * (r + 1)) * Math.Sqrt((5 - Math.Sqrt(5)) / 8) - Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r / (2 * (r + 1)) * (-Math.Sqrt(5) - 1) / 4); pointNames[34] = "N_5,3";
            points[35] = new Point3D(-((3 + Math.Sqrt(5)) * r - 2) / (2 * Math.Sqrt(5) * (r + 1)), -((5 + 7 * Math.Sqrt(5)) * r + 2 * Math.Sqrt(5) + 10) / (20 * (r + 1)), (((3 + Math.Sqrt(5)) * r + 8) / (4 * Math.Sqrt(5) * (r + 1))) * (-Math.Sqrt((5 - Math.Sqrt(5)) / 8)) + (-Math.Sqrt(5 + Math.Sqrt(5)) * r / (2 * Math.Sqrt(2) * (r + 1))) * ((-Math.Sqrt(5) - 1) / 4)); pointNames[35] = "N_5,4";
            points[36] = new Point3D(Math.Sqrt(5) / 5, (-5 - Math.Sqrt(5)) / 10, (8 * Math.Sqrt(5 * (5 + 2 * Math.Sqrt(5))) * r - 4 * Math.Sqrt(50 - 10 * Math.Sqrt(5))) / (40 * (r + 1))); pointNames[36] = "N_5,5";

            points[37] = new Point3D(((5 + Math.Sqrt(5)) * r + Math.Sqrt(5)) / (5 * (r + 1)), 1 / (2 * (r + 1)) - 1 / (2 * Math.Sqrt(5)), (Math.Sqrt((5 + Math.Sqrt(5)) / 2) * (Math.Sqrt(5) * r + 5 * r - 4 * Math.Sqrt(5))) / (20 * (r + 1))); pointNames[37] = "N_6,1";
            points[38] = new Point3D(Math.Sqrt(5) / 5, ((Math.Sqrt(5) - 1)*(4 - r)) / (8*Math.Sqrt(5)*(r + 1)) + Math.Sqrt( (5 + Math.Sqrt(5))*(5 + 2*Math.Sqrt(5))/2)*r/ (4*(r + 1)), (Math.Sqrt(5 * (5 + 2 * Math.Sqrt(5))) * r - Math.Sqrt(10 * (5 + Math.Sqrt(5)))) / (10 * (r + 1))); pointNames[38] = "N_6,2";
            points[39] = new Point3D(-((3 + Math.Sqrt(5)) * r - 2) / (2 * Math.Sqrt(5) * (r + 1)), (3 * Math.Sqrt(5) * r + 15 * r - 2 * Math.Sqrt(5) + 10) / (20 * (r + 1)), -(Math.Sqrt(2 * (5 + Math.Sqrt(5))) * ((5 - Math.Sqrt(5)) * r + 4 * Math.Sqrt(5))) / (40 * (r + 1))); pointNames[39] = "N_6,3";
            points[40] = new Point3D((2 - (3 + Math.Sqrt(5)) * r) / (2 * Math.Sqrt(5) * (1 + r)), -((5 + Math.Sqrt(5)) * r) / (8 * (1 + r)) + ((-1 + Math.Sqrt(5)) * (8 + (3 + Math.Sqrt(5)) * r)) / (16 * Math.Sqrt(5) * (1 + r)), -Math.Sqrt((5 + Math.Sqrt(5)) / 10)); pointNames[40] = "N_6,4";
            points[41] = new Point3D(Math.Sqrt(5) / 5, -((15 + 7 * Math.Sqrt(5)) * r + 2 * Math.Sqrt(5) - 10) / (20 * (r + 1)), (Math.Sqrt(10 * (5 + Math.Sqrt(5))) * (r - 4) - 5 * (Math.Sqrt(5) - 1) * Math.Sqrt(5 + 2 * Math.Sqrt(5)) * r) / (40 * (r + 1))); pointNames[41] = "N_6,5";

            // Initialize N_7,1 to N_12,5 with ((-1)*(0), (-1)*(0), (-1)*(0))
            points[42] = points[12].Negate(); pointNames[42] = "N_7,1";
            points[43] = points[13].Negate(); pointNames[43] = "N_7,2";
            points[44] = points[14].Negate(); pointNames[44] = "N_7,3";
            points[45] = points[15].Negate(); pointNames[45] = "N_7,4";
            points[46] = points[16].Negate(); pointNames[46] = "N_7,5";

            points[47] = points[17].Negate(); pointNames[47] = "N_8,1";
            points[48] = points[18].Negate(); pointNames[48] = "N_8,2";
            points[49] = points[19].Negate(); pointNames[49] = "N_8,3";
            points[50] = points[20].Negate(); pointNames[50] = "N_8,4";
            points[51] = points[21].Negate(); pointNames[51] = "N_8,5";

            points[52] = points[22].Negate(); pointNames[52] = "N_9,1";
            points[53] = points[23].Negate(); pointNames[53] = "N_9,2";
            points[54] = points[24].Negate(); pointNames[54] = "N_9,3";
            points[55] = points[25].Negate(); pointNames[55] = "N_9,4";
            points[56] = points[26].Negate(); pointNames[56] = "N_9,5";

            points[57] = points[27].Negate(); pointNames[57] = "N_10,1";
            points[58] = points[28].Negate(); pointNames[58] = "N_10,2";
            points[59] = points[29].Negate(); pointNames[59] = "N_10,3";
            points[60] = points[30].Negate(); pointNames[60] = "N_10,4";
            points[61] = points[31].Negate(); pointNames[61] = "N_10,5";

            points[62] = points[32].Negate(); pointNames[62] = "N_11,1";
            points[63] = points[33].Negate(); pointNames[63] = "N_11,2";
            points[64] = points[34].Negate(); pointNames[64] = "N_11,3";
            points[65] = points[35].Negate(); pointNames[65] = "N_11,4";
            points[66] = points[36].Negate(); pointNames[66] = "N_11,5";

            points[67] = points[37].Negate(); pointNames[67] = "N_12,1";
            points[68] = points[38].Negate(); pointNames[68] = "N_12,2";
            points[69] = points[39].Negate(); pointNames[69] = "N_12,3";
            points[70] = points[40].Negate(); pointNames[70] = "N_12,4";
            points[71] = points[41].Negate(); pointNames[71] = "N_12,5";

            double totalDotProductSum = 0;
            for (int i = 0; i < 72; i++)
            {
                points[i] = points[i].Multiply(factor);
            }

            var results = new List<Tuple<string, string, double>>();

            for (int i = 0; i < points.Length; i++)
            {
                for (int j = i + 1; j < points.Length; j++)
                {
                    // Check if both points are of type N_i,j
                    if (pointNames[i].StartsWith("N_") && pointNames[j].StartsWith("N_"))
                    {
                        double dotProduct = DotProduct(points[i], points[j]);
                        totalDotProductSum += dotProduct;
                        results.Add(Tuple.Create(pointNames[i], pointNames[j], dotProduct));
                    }
                }
            }

            // Sort results by dot product value in descending order
            results = results.OrderByDescending(result => result.Item3).ToList();

            // Write results to the file
            string filePath = @"C:\Users\stefa\Documents\Programming\C60 Spectyr\DotProductResults.txt";
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var result in results)
                {
                    writer.WriteLine($"Dot product between {result.Item1} {points[Array.IndexOf(pointNames, result.Item1)]} and {result.Item2} {points[Array.IndexOf(pointNames, result.Item2)]} is {result.Item3}");
                }

                writer.WriteLine($"Total sum of all dot products: {totalDotProductSum}");
            }

            Console.WriteLine($"Dot product results saved to {filePath}");

            // Count and write unique dot products to another file
            var results1 = new List<Tuple<string, string, double>>();
            HashSet<double> seenDotProducts = new HashSet<double>();

            for (int i = 0; i < points.Length; i++)
            {
                for (int j = i + 1; j < points.Length; j++)
                {
                    // Check if both points are of type N_i,j
                    if (pointNames[i].StartsWith("N_") && pointNames[j].StartsWith("N_"))
                    {
                        double dotProduct = DotProduct(points[i], points[j]);

                        // Check if this dot product value has been seen before
                        if (!seenDotProducts.Contains(dotProduct))
                        {
                            results1.Add(Tuple.Create(pointNames[i], pointNames[j], dotProduct));
                            seenDotProducts.Add(dotProduct);
                        }
                    }
                }
            }

            // Sort results1 by dot product value in descending order
            results1 = results1.OrderByDescending(result => result.Item3).ToList();

            // Count the number of different dot products
            int differentDotProductCount = seenDotProducts.Count;

            // Write results1 to the file
            string filePath1 = @"C:\Users\stefa\Documents\Programming\C60 Spectyr\DotProductResults1.txt";
            using (StreamWriter writer = new StreamWriter(filePath1))
            {
                writer.WriteLine($"Total number of different dot products: {differentDotProductCount}");
                writer.WriteLine(); // Blank line for readability

                foreach (var result in results1)
                {
                    writer.WriteLine($"Dot product between {result.Item1} {points[Array.IndexOf(pointNames, result.Item1)]} and {result.Item2} {points[Array.IndexOf(pointNames, result.Item2)]} is {result.Item3}");
                }

                writer.WriteLine(); // Blank line for readability
                writer.WriteLine($"Total sum of all dot products: {totalDotProductSum}");
            }

            Console.WriteLine($"Dot product results1 saved to {filePath1}");

        var distances = new List<Tuple<string, double>>();
            for (int i = 0; i < points.Length; i++)
            {
                double distance = DistanceFromOrigin(points[i]);
                distances.Add(new Tuple<string, double>(pointNames[i], distance));
            }
            using (StreamWriter writer = new StreamWriter(@"C:\Users\stefa\Documents\Programming\C60 Spectyr\Distances.txt"))
            {
                writer.WriteLine("\nDistances from Origin:");
                foreach (var distance in distances)
                {
                    writer.WriteLine($"Distance of {distance.Item1} ({points[Array.IndexOf(pointNames, distance.Item1)]}) from origin: {distance.Item2:F6}");
                }
            }
            Console.WriteLine("Dot product results1 saved to Distances.txt");
        }
    }
}  
    